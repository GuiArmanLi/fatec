<?php

$continue = 5;
while ($continue <= 200) {
    echo $continue++ . "\n";
}
