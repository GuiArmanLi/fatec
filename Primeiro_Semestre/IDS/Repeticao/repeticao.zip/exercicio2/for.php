<?php

for ($continue = 5; $continue <= 200; $continue++) {
    echo $continue . "\n";
}
