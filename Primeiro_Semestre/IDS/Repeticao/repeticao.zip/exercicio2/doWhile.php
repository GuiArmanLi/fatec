<?php

$continue = 5;
do {
    echo $continue++ . "\n";
} while ($continue <= 200);
