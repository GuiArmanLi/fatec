<?php

$continue = 500;
while ($continue >= 1) {
    echo $continue-- . "\n";
}
