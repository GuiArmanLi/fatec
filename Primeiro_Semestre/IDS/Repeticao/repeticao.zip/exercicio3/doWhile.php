<?php

$continue = 500;
do {
    echo $continue-- . "\n";
} while ($continue >= 1);
