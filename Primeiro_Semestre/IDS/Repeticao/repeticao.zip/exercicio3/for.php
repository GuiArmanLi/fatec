<?php

for ($continue = 500; $continue >= 1; $continue--) {
    echo $continue . "\n";
}
