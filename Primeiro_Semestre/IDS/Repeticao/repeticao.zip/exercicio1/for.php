<?php

for ($continue = 1; $continue <= 1000; $continue++) {
    echo $continue . "\n";
}
