<?php

$continue = 1;
while ($continue <= 1000) {
    echo $continue++ . "\n";
}
