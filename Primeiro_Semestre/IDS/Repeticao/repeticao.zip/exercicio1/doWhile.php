<?php

$continue = 1;
do {
    echo $continue++ . "\n";
} while ($continue <= 1000);
